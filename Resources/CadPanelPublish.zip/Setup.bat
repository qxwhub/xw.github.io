@echo off
cd /d "%~dp0"
title CadPanel Setup

set "DLL=%~dp0Contents\CadPanel.dll"
set "LOGFILE=%~dp0Setup_Log.txt"
echo %date% %time% CadPanel Setup Log > "%LOGFILE%"

rem ===== Admin detection (HKLM write requires admin) =====
rem Query LocalService registry key (only admins can read it)
reg query "HKU\S-1-5-19" >nul 2>&1
if errorlevel 1 (
    set "ADMIN=0"
    set "HKLM_NOTE= [HKLM skipped: not admin]"
    echo [WARN] Not running as admin. HKLM registration skipped. >> "%LOGFILE%"
) else (
    set "ADMIN=1"
    set "HKLM_NOTE="
    echo [OK] Running as admin >> "%LOGFILE%"
)

echo.
echo   ======================================
echo       CadPanel Setup
echo   ======================================
echo.
echo   1. Install
echo   2. Uninstall
echo.
set /p "OPTION=Select (1/2): "

if "%OPTION%"=="1" call :DoInstall
if "%OPTION%"=="2" call :DoUninstall
goto :End

:DoInstall
echo.
if not exist "%DLL%" (
    echo   [FAIL] CadPanel.dll not found!
    echo   Path: %DLL%
    echo [FAIL] CadPanel.dll NOT found >> "%LOGFILE%"
    goto :EOF
)
echo   [ OK ] CadPanel.dll
echo [OK] CadPanel.dll found at %DLL% >> "%LOGFILE%"

reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release >nul 2>&1
if errorlevel 1 (
    echo   [FAIL] .NET Framework 4.x not found!
    goto :EOF
)
for /f "tokens=2*" %%R in ('reg query "HKLM\SOFTWARE\Microsoft\NET Framework Setup\NDP\v4\Full" /v Release 2^>nul ^| find "Release"') do set "VER=%%S"
set "VER=%VER: =%"
if "%VER%"=="" goto :EOF
if %VER% LSS 528040 (
    echo   [FAIL] .NET Framework 4.8+ required! Found older version.
    goto :EOF
)
echo   [ OK ] .NET Framework 4.8+

echo.
echo   Searching for AutoCAD versions...%HKLM_NOTE%
echo Searching for AutoCAD versions... >> "%LOGFILE%"
set "COUNT=0"

rem ===== Scan HKCU (always, current user) =====
for /f "tokens=*" %%V in ('reg query "HKCU\Software\Autodesk\AutoCAD" 2^>nul') do (
    for /f "tokens=*" %%A in ('reg query "%%V" 2^>nul') do (
        set "LINE=%%A"
        call :RegisterVersion
    )
)

rem ===== Scan HKLM (admin only, per-machine installs not yet launched by user) =====
if "%ADMIN%"=="1" (
    for /f "tokens=*" %%V in ('reg query "HKLM\SOFTWARE\Autodesk\AutoCAD" 2^>nul') do (
        for /f "tokens=*" %%A in ('reg query "%%V" 2^>nul') do (
            set "LINE=%%A"
            call :RegisterVersion
        )
    )
)

echo.
if "%COUNT%"=="0" (
    echo   [WARN] No AutoCAD found in registry.
    echo.
    echo   Checked: HKCU\Software\Autodesk\AutoCAD
    if "%ADMIN%"=="1" (
        echo   Checked: HKLM\SOFTWARE\Autodesk\AutoCAD
    ) else (
        echo   HKLM not checked ^(not admin^). Re-run as admin if CAD is per-machine.
    )
    echo.
    echo   If CAD is installed but not found, launch the CAD version once first,
    echo   then re-run this script.
    echo [FAIL] No AutoCAD found >> "%LOGFILE%"
    goto :EOF
)

echo   ======================================
echo   Install complete! (%COUNT% registrations^)
echo   ======================================
echo.
echo   Restart AutoCAD to see "CadPanel" menu.
echo [OK] Install complete, %COUNT% registration(s) >> "%LOGFILE%"
goto :EOF

:RegisterVersion
echo %LINE% | findstr /i "\\ACAD-" >nul 2>&1
if errorlevel 1 goto :EOF

set "SUB=%LINE%"
rem Normalize hive prefix: HKEY_CURRENT_USER -> HKCU, HKEY_LOCAL_MACHINE -> HKLM
set "SUB=%SUB:HKEY_CURRENT_USER\=HKCU\%"
set "SUB=%SUB:HKEY_LOCAL_MACHINE\=HKLM\%"

reg add "%SUB%\Applications\CadPanel" /v DESCRIPTION /t REG_SZ /d "CadPanel" /f >nul 2>&1
reg add "%SUB%\Applications\CadPanel" /v LOADCTRLS  /t REG_DWORD /d 2 /f >nul 2>&1
reg add "%SUB%\Applications\CadPanel" /v LOADER     /t REG_SZ /d "%DLL%" /f >nul 2>&1
reg add "%SUB%\Applications\CadPanel" /v MANAGED    /t REG_DWORD /d 1 /f >nul 2>&1
set /a COUNT=%COUNT%+1
echo   [ OK ] CadPanel ^> %SUB%
echo [OK] Registered CadPanel to %SUB% >> "%LOGFILE%"
goto :EOF

:DoUninstall
echo.
echo   Uninstalling...%HKLM_NOTE%
echo Uninstalling... >> "%LOGFILE%"

set "COUNT=0"

for /f "tokens=*" %%V in ('reg query "HKCU\Software\Autodesk\AutoCAD" 2^>nul') do (
    for /f "tokens=*" %%A in ('reg query "%%V" 2^>nul') do (
        set "LINE=%%A"
        call :UnregisterVersion
    )
)

if "%ADMIN%"=="1" (
    for /f "tokens=*" %%V in ('reg query "HKLM\SOFTWARE\Autodesk\AutoCAD" 2^>nul') do (
        for /f "tokens=*" %%A in ('reg query "%%V" 2^>nul') do (
            set "LINE=%%A"
            call :UnregisterVersion
        )
    )
)

echo.
if not "%COUNT%"=="0" (
    echo   ======================================
    echo   Uninstall complete! (%COUNT% registrations^)
    echo   ======================================
    echo.
    echo   Plugin files NOT deleted.
    echo [OK] Uninstall complete, %COUNT% registration(s) >> "%LOGFILE%"
) else (
    echo   [INFO] Not installed. Nothing to uninstall.
    echo [INFO] Nothing to uninstall >> "%LOGFILE%"
)
goto :EOF

:UnregisterVersion
echo %LINE% | findstr /i "\\ACAD-" >nul 2>&1
if errorlevel 1 goto :EOF

set "SUB=%LINE%"
set "SUB=%SUB:HKEY_CURRENT_USER\=HKCU\%"
set "SUB=%SUB:HKEY_LOCAL_MACHINE\=HKLM\%"

reg delete "%SUB%\Applications\CadPanel" /f >nul 2>&1
set /a COUNT=%COUNT%+1
echo   [ OK ] %SUB%
echo [OK] Unregistered from %SUB% >> "%LOGFILE%"
goto :EOF

:End
echo.
pause
