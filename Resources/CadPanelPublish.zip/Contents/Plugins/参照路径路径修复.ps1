﻿Add-Type -AssemblyName System.Windows.Forms,System.Drawing

$acadProgIDs = @("AutoCAD.Application.25.0","AutoCAD.Application.24.3","AutoCAD.Application.24.2","AutoCAD.Application.24.1","AutoCAD.Application.24.0","AutoCAD.Application.23.1")

$form = New-Object System.Windows.Forms.Form
$form.Text = "AutoCAD XREF 批量路径修复工具"
$form.Size = New-Object System.Drawing.Size(600,400)
$form.StartPosition = "CenterScreen"
$form.FormBorderStyle = "FixedDialog"
$form.MaximizeBox = $false

$titleLabel = New-Object System.Windows.Forms.Label
$titleLabel.Text = "AutoCAD XREF 批量路径修复工具"
$titleLabel.Size = New-Object System.Drawing.Size(560,30)
$titleLabel.Location = New-Object System.Drawing.Point(15,15)
$titleLabel.Font = New-Object System.Drawing.Font("Microsoft YaHei",14,[System.Drawing.FontStyle]::Bold)
$titleLabel.TextAlign = "MiddleCenter"
$form.Controls.Add($titleLabel)

$lbl1 = New-Object System.Windows.Forms.Label
$lbl1.Text = "1. 图纸文件夹（待修复的 DWG 文件）："
$lbl1.Size = New-Object System.Drawing.Size(560,20)
$lbl1.Location = New-Object System.Drawing.Point(15,60)
$form.Controls.Add($lbl1)

$txtPaper = New-Object System.Windows.Forms.TextBox
$txtPaper.Size = New-Object System.Drawing.Size(450,25)
$txtPaper.Location = New-Object System.Drawing.Point(15,82)
$form.Controls.Add($txtPaper)

$btnPaper = New-Object System.Windows.Forms.Button
$btnPaper.Text = "浏览..."
$btnPaper.Size = New-Object System.Drawing.Size(80,25)
$btnPaper.Location = New-Object System.Drawing.Point(475,81)
$btnPaper.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "选择包含需要修复 XREF 路径的 DWG 文件夹"
    if ($dlg.ShowDialog() -eq "OK") { $txtPaper.Text = $dlg.SelectedPath }
})
$form.Controls.Add($btnPaper)

$lbl2 = New-Object System.Windows.Forms.Label
$lbl2.Text = "2. 模型文件夹（XREF .dwg 文件所在位置）："
$lbl2.Size = New-Object System.Drawing.Size(560,20)
$lbl2.Location = New-Object System.Drawing.Point(15,120)
$form.Controls.Add($lbl2)

$txtModel = New-Object System.Windows.Forms.TextBox
$txtModel.Size = New-Object System.Drawing.Size(450,25)
$txtModel.Location = New-Object System.Drawing.Point(15,142)
$form.Controls.Add($txtModel)

$btnModel = New-Object System.Windows.Forms.Button
$btnModel.Text = "浏览..."
$btnModel.Size = New-Object System.Drawing.Size(80,25)
$btnModel.Location = New-Object System.Drawing.Point(475,141)
$btnModel.Add_Click({
    $dlg = New-Object System.Windows.Forms.FolderBrowserDialog
    $dlg.Description = "选择包含 XREF 模型 .dwg 文件的文件夹"
    if ($dlg.ShowDialog() -eq "OK") { $txtModel.Text = $dlg.SelectedPath }
})
$form.Controls.Add($btnModel)

$lbl3 = New-Object System.Windows.Forms.Label
$lbl3.Text = "3. acad.exe 路径："
$lbl3.Size = New-Object System.Drawing.Size(560,20)
$lbl3.Location = New-Object System.Drawing.Point(15,180)
$form.Controls.Add($lbl3)

$txtAcad = New-Object System.Windows.Forms.TextBox
$txtAcad.Size = New-Object System.Drawing.Size(450,25)
$txtAcad.Location = New-Object System.Drawing.Point(15,202)
$txtAcad.Text = "C:\Program Files\Autodesk\AutoCAD 2022\acad.exe"
$form.Controls.Add($txtAcad)

$btnAcad = New-Object System.Windows.Forms.Button
$btnAcad.Text = "浏览..."
$btnAcad.Size = New-Object System.Drawing.Size(80,25)
$btnAcad.Location = New-Object System.Drawing.Point(475,201)
$btnAcad.Add_Click({
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title = "选择 acad.exe"
    $dlg.Filter = "acad.exe|acad.exe"
    if ($dlg.ShowDialog() -eq "OK") { $txtAcad.Text = $dlg.FileName }
})
$form.Controls.Add($btnAcad)

$chkSub = New-Object System.Windows.Forms.CheckBox
$chkSub.Text = "包含子文件夹（递归扫描）"
$chkSub.Size = New-Object System.Drawing.Size(300,25)
$chkSub.Location = New-Object System.Drawing.Point(15,240)
$chkSub.Checked = $true
$form.Controls.Add($chkSub)

$lblProgress = New-Object System.Windows.Forms.Label
$lblProgress.Size = New-Object System.Drawing.Size(560,20)
$lblProgress.Location = New-Object System.Drawing.Point(15,275)
$lblProgress.ForeColor = "Blue"
$form.Controls.Add($lblProgress)

$btnStart = New-Object System.Windows.Forms.Button
$btnStart.Text = "开始修复"
$btnStart.Size = New-Object System.Drawing.Size(150,45)
$btnStart.Location = New-Object System.Drawing.Point(15,310)
$btnStart.BackColor = "#4CAF50"
$btnStart.ForeColor = "White"
$btnStart.Font = New-Object System.Drawing.Font("Microsoft YaHei",11,[System.Drawing.FontStyle]::Bold)
$btnStart.Add_Click({
    if ([string]::IsNullOrWhiteSpace($txtPaper.Text) -or -not (Test-Path $txtPaper.Text)) {
        [System.Windows.Forms.MessageBox]::Show("请选择有效的图纸文件夹！","错误","OK","Warning")
        return
    }
    if ([string]::IsNullOrWhiteSpace($txtModel.Text) -or -not (Test-Path $txtModel.Text)) {
        [System.Windows.Forms.MessageBox]::Show("请选择有效的模型文件夹！","错误","OK","Warning")
        return
    }
    if ([string]::IsNullOrWhiteSpace($txtAcad.Text) -or -not (Test-Path $txtAcad.Text)) {
        [System.Windows.Forms.MessageBox]::Show("请选择有效的 acad.exe 路径！","错误","OK","Warning")
        return
    }

    $btnStart.Enabled = $false
    $btnStart.Text = "正在处理..."
    $lblProgress.Text = "准备中..."
    $form.Refresh()

    $acadPath = $txtAcad.Text
    $paperPath = $txtPaper.Text
    $modelPath = $txtModel.Text
    $recurse = $chkSub.Checked

    $lblProgress.Text = "正在扫描文件..."
    $form.Refresh()

    $dwgFiles = if ($recurse) {
        Get-ChildItem -Path $paperPath -Recurse -File -Filter "*.dwg"
    } else {
        Get-ChildItem -Path $paperPath -File -Filter "*.dwg"
    }
    $total = $dwgFiles.Count
    $acadName = [System.IO.Path]::GetFileName([System.IO.Path]::GetDirectoryName($acadPath))

    $lblProgress.Text = "已找到 $total 个文件，正在连接 AutoCAD ..."
    $form.Refresh()

    $acadApp = $null

    if (-not (Test-Path $acadPath)) {
        [System.Windows.Forms.MessageBox]::Show("acad.exe 未找到：`r`n$acadPath`r`n请浏览并选择正确的 acad.exe！","错误","OK","Error")
        $btnStart.Enabled = $true; $btnStart.Text = "开始修复"; $lblProgress.Text = ""; return
    }

    Get-Process -Name "acad" -ErrorAction SilentlyContinue | ForEach-Object {
        try {
            if ($_.Path -eq $acadPath) { Stop-Process -Id $_.Id -Force -ErrorAction SilentlyContinue }
        } catch {}
    }
    Start-Sleep -Seconds 3

    $proc = Start-Process -FilePath $acadPath -WindowStyle Minimized -PassThru
    $lblProgress.Text = "正在启动 AutoCAD ..."
    $form.Refresh()

    $r = 0
    while ($r -lt 15 -and -not $acadApp) {
        Start-Sleep -Seconds 6
        $r++
        foreach ($progID in $acadProgIDs) {
            try { $acadApp = [Runtime.Interopservices.Marshal]::GetActiveObject($progID); break } catch {}
        }
    }

    if (-not $acadApp) {
        [System.Windows.Forms.MessageBox]::Show("无法连接到 AutoCAD！请确认已安装。","错误","OK","Error")
        $btnStart.Enabled = $true
        $btnStart.Text = "开始修复"
        $lblProgress.Text = ""
        return
    }

    Write-Host "Connected to AutoCAD $($acadApp.Version) at $($acadApp.Path)"
    Start-Sleep -Seconds 5
    try { $acadApp.Visible = $false } catch {}
    $acadApp.SetSystemVariable("FILEDIA", 0)
    $acadApp.SetSystemVariable("CMDDIA", 0)
    $acadApp.SetSystemVariable("EXPERT", 5)
    $acadApp.SetSystemVariable("SDI", 0)

    $lblProgress.Text = "正在索引模型文件..."
    $form.Refresh()

    $lookup = @{}
    $modelFiles = Get-ChildItem -Path $modelPath -Recurse -File -Filter "*.dwg"
    foreach ($mf in $modelFiles) {
        if (-not $lookup.ContainsKey($mf.BaseName)) { $lookup[$mf.BaseName] = $mf.FullName }
        if (-not $lookup.ContainsKey($mf.Name)) { $lookup[$mf.Name] = $mf.FullName }
    }

    $okCount = 0
    $failCount = 0
    $fixedCount = 0
    $notFoundCount = 0

    for ($i = 0; $i -lt $total; $i++) {
        $df = $dwgFiles[$i]
        $cf = $df.Name
        $ff = 0
        $fn = 0

        $lblProgress.Text = "[$($i+1)/$total] $cf"
        $form.Refresh()

        try {
            $doc = $acadApp.Documents.Open($df.FullName, $false, $false)
            Start-Sleep -Seconds 2

            foreach ($blk in $doc.Blocks) {
                if ($blk.IsXRef) {
                    $xn = $blk.Name
                    $mpn = $null

                    if ($lookup.ContainsKey($xn)) { $mpn = $lookup[$xn] }
                    if (-not $mpn) {
                        $xe = $xn -replace '\.dwg$', ''
                        if ($lookup.ContainsKey($xe)) { $mpn = $lookup[$xe] }
                    }
                    if (-not $mpn) {
                        $xb = [System.IO.Path]::GetFileNameWithoutExtension($xn)
                        $mm = $modelFiles | Where-Object { $_.BaseName -eq $xb } | Select-Object -First 1
                        if ($mm) { $mpn = $mm.FullName }
                    }

                    if ($mpn) {
                        try { $blk.Path = $mpn; $ff++ } catch { $fn++ }
                    } else {
                        $fn++
                    }
                }
            }

            try { $doc.Save() } catch {}
            Start-Sleep -Seconds 1
            $doc.Close()
            Start-Sleep -Seconds 1

            $okCount++
            $fixedCount += $ff
            $notFoundCount += $fn
        } catch {
            $failCount++
        }
    }

    try {
        $acadApp.SetSystemVariable("FILEDIA", 1)
        $acadApp.SetSystemVariable("CMDDIA", 1)
        $acadApp.SetSystemVariable("EXPERT", 0)
        $acadApp.Visible = $true
    } catch {}

    $result = "========== 完成 ==========`r`n"
    $result += "总数: $total`r`n"
    $result += "成功: $okCount`r`n"
    $result += "失败: $failCount`r`n"
    $result += "已修复: $fixedCount`r`n"
    $result += "未找到: $notFoundCount"
    
    [System.Windows.Forms.MessageBox]::Show($result, "结果", "OK", "Information")

    $btnStart.Enabled = $true
    $btnStart.Text = "开始修复"
    $lblProgress.Text = "完成！已修复 $fixedCount 个 XREF"
})
$form.Controls.Add($btnStart)

$btnExit = New-Object System.Windows.Forms.Button
$btnExit.Text = "退出"
$btnExit.Size = New-Object System.Drawing.Size(100,45)
$btnExit.Location = New-Object System.Drawing.Point(180,310)
$btnExit.Font = New-Object System.Drawing.Font("Microsoft YaHei",11)
$btnExit.Add_Click({ $form.Close() })
$form.Controls.Add($btnExit)

[void] $form.ShowDialog()